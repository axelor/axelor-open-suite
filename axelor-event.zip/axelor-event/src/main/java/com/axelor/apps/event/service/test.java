package com.axelor.apps.event.service;

public class test {}
