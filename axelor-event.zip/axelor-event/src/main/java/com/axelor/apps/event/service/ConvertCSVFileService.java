package com.axelor.apps.event.service;
import com.axelor.exception.AxelorException;

public class ConvertCSVFileService {
public MetaFile convertExcelFile(File excelFile)
      throws IOException, AxelorException, ParseException;
}
