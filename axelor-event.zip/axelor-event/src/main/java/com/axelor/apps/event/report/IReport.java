package com.axelor.apps.event.report;

public interface IReport {

  public static final String INVOICE_GST = "EventDetails.rptdesign";
}
